/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.7.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtNetwork/QSslPreSharedKeyAuthenticator>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.7.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "handleVolumeButton",
    "",
    "handleBackButton",
    "handleStopButton",
    "handleForwardButton",
    "handlePlayPauseButton",
    "handleVolumeSliderChange",
    "value",
    "handleDurationSliderMove",
    "handleDurationSliderRelease",
    "durationChanged",
    "duration",
    "positionChanged",
    "position",
    "addSongToQueue",
    "QListWidgetItem*",
    "item",
    "playNextInQueue",
    "updateCurrentlyPlayingLabel",
    "handlePlaybackStateChanged",
    "QMediaPlayer::PlaybackState",
    "state",
    "updateSongQueueTable",
    "handlePushButtonEditTrackInfo",
    "handleRemoveSongFromQueue",
    "clearQueue",
    "handleAllSongsCellChanged",
    "on_actionSelect_File_mp3_triggered",
    "editList",
    "on_actionClear_History_triggered"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  146,    2, 0x08,    1 /* Private */,
       3,    0,  147,    2, 0x08,    2 /* Private */,
       4,    0,  148,    2, 0x08,    3 /* Private */,
       5,    0,  149,    2, 0x08,    4 /* Private */,
       6,    0,  150,    2, 0x08,    5 /* Private */,
       7,    1,  151,    2, 0x08,    6 /* Private */,
       9,    1,  154,    2, 0x08,    8 /* Private */,
      10,    0,  157,    2, 0x08,   10 /* Private */,
      11,    1,  158,    2, 0x08,   11 /* Private */,
      13,    1,  161,    2, 0x08,   13 /* Private */,
      15,    1,  164,    2, 0x08,   15 /* Private */,
      18,    0,  167,    2, 0x08,   17 /* Private */,
      19,    0,  168,    2, 0x08,   18 /* Private */,
      20,    1,  169,    2, 0x08,   19 /* Private */,
      23,    0,  172,    2, 0x08,   21 /* Private */,
      24,    0,  173,    2, 0x08,   22 /* Private */,
      25,    0,  174,    2, 0x08,   23 /* Private */,
      26,    0,  175,    2, 0x08,   24 /* Private */,
      27,    1,  176,    2, 0x08,   25 /* Private */,
      28,    0,  179,    2, 0x08,   27 /* Private */,
      29,    0,  180,    2, 0x08,   28 /* Private */,
      30,    0,  181,    2, 0x08,   29 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::LongLong,   12,
    QMetaType::Void, QMetaType::LongLong,   14,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'handleVolumeButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleBackButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleStopButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleForwardButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handlePlayPauseButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleVolumeSliderChange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'handleDurationSliderMove'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'handleDurationSliderRelease'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'durationChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qint64, std::false_type>,
        // method 'positionChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qint64, std::false_type>,
        // method 'addSongToQueue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'playNextInQueue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateCurrentlyPlayingLabel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handlePlaybackStateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMediaPlayer::PlaybackState, std::false_type>,
        // method 'updateSongQueueTable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handlePushButtonEditTrackInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleRemoveSongFromQueue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearQueue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleAllSongsCellChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'on_actionSelect_File_mp3_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'editList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionClear_History_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->handleVolumeButton(); break;
        case 1: _t->handleBackButton(); break;
        case 2: _t->handleStopButton(); break;
        case 3: _t->handleForwardButton(); break;
        case 4: _t->handlePlayPauseButton(); break;
        case 5: _t->handleVolumeSliderChange((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->handleDurationSliderMove((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->handleDurationSliderRelease(); break;
        case 8: _t->durationChanged((*reinterpret_cast< std::add_pointer_t<qint64>>(_a[1]))); break;
        case 9: _t->positionChanged((*reinterpret_cast< std::add_pointer_t<qint64>>(_a[1]))); break;
        case 10: _t->addSongToQueue((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 11: _t->playNextInQueue(); break;
        case 12: _t->updateCurrentlyPlayingLabel(); break;
        case 13: _t->handlePlaybackStateChanged((*reinterpret_cast< std::add_pointer_t<QMediaPlayer::PlaybackState>>(_a[1]))); break;
        case 14: _t->updateSongQueueTable(); break;
        case 15: _t->handlePushButtonEditTrackInfo(); break;
        case 16: _t->handleRemoveSongFromQueue(); break;
        case 17: _t->clearQueue(); break;
        case 18: _t->handleAllSongsCellChanged((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 19: _t->on_actionSelect_File_mp3_triggered(); break;
        case 20: _t->editList(); break;
        case 21: _t->on_actionClear_History_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
